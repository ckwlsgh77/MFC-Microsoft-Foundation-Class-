//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// My20150281Practice51.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_My20150281Practice51TYPE    130
#define IDS_EDIT_MENU                   306
#define ID_INDICATOR_POINT              310
#define ID_32771                        32771
#define ID_LINE                         32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_ELLIPSE                      32776
#define ID_POLYGON                      32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_LINE_COLOR                   32780
#define ID_FACE_COLOR                   32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_BDIAGONAL                    32786
#define ID_CROSS                        32787
#define ID_VERTICAL                     32788
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32802
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           311
#endif
#endif
